import React from 'react'
import Layout from '../layout/Layout'

const Contact = () => {
  return (
    <Layout title={'Contact'}>
      
    </Layout>
  )
}

export default Contact
