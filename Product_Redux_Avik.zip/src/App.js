import logo from './logo.svg';
import './App.css';
import Routing from './router/Routing';

function App() {
  return (
    <>
      <Routing/>
    </>
  );
}

export default App;
